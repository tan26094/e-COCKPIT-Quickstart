


For 750-820x FW6:
Store Recipe file ("Installation.Recipes.txtrecipe") in PLC folder "/home/codesys_root/"


For 750-820x FW8 or newer:
Store Recipe file ("Installation.Recipes.txtrecipe") in PLC folder "/home/codesys_root/PlcLogic"

